# onlocation

On Location Project

(Team#8) Final Level: Sean, Angela, Natalee

Searchable database by country and state (for USA) which movies were
filmed in that state. Once movie selected then shows poster of the movie,
youtube trailer and synopsis.

API’s
-myapifilms
-youtube trailers
-google maps
-omdb or the movie db

Front End: Natalee/Angela
Back End: Sean/Angela
